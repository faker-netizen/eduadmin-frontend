import {defineConfig} from '@umijs/max'; // antd主题色（v4和v5通用）

// antd主题色（v4和v5通用）
const primaryColor = '#799cd0';

// 获取antd版本号（v4或v5）
const antdVersion = require('antd/package.json').version.split('.')[0];

export default defineConfig({

  reactQuery:{
    queryClient:true
  },
  antd:
    antdVersion === '4'
      ? {}
      : {
          theme: {
            token: {
              colorPrimary: primaryColor,
            },
          },
        },
  history: {
    type: 'hash',
  },
  model: {},
  npmClient: 'npm',
  proxy: {
    '/api': {
      target: 'http://47.102.141.212:8082',
      changeOrigin: true,
      pathRewrite: { '^/api': '' },
    },
  },
  request: {},
  routes: [
    {
      path: '/login',
      component: '@/pages/Login/index',
      wrappers: ['@/wrappers/auth'],
    },
    {
      exact: false,
      path: '/',

      wrappers: ['@/wrappers/auth'],
      routes: [
        { path: '/user', component: '@/pages/User/index' },
        {
          path: '/accountManage/studentList',
          component: '@/pages/AccountManage/StudentList/index',
        },
        {
          path: '/accountManage/teacherList',
          component: '@/pages/AccountManage/TeacherList/index',
        },
        {
          path: '/accountManage/permission',
          component: '@/pages/AccountManage/Permission/index',
        },
        {
          path: '/accountManage/accountList',
          component: '@/pages/AccountManage/AccountList/index',
        },
        {
          path: '/accountManage/userAccount',
          component: '@/pages/AccountManage/UserAccount/index',
        },
        {
          path: '/accountManage/formFormat',
          component: '@/pages/AccountManage/FormFormat/index',
        },
        { path: '/fileManage', component: '@/pages/FileManage/index' },
        {
          path: '/informationManage',
          component: '@/pages/InformationManage/InformationManage/index',
        },
        {
          path: '/courseManage/courseList',
          component: '@/pages/CourseList/index',
        },
        {
          path: '/courseManage/courseManage',
          component: '@/pages/CourseManage/CourseManage/index',
        },
        {
          path: '/courseManage/teacherCourse',
          component: '@/pages/CourseManage/TeacherCourse/index',
        },
        {
          path: '/accountManage/classroom',
          component: '@/pages/CourseManage/ClassroomManage/index',
        },
        {
          path: '/courseManage/courseModel',
          component: '@/pages/CourseManage/CourseModelManage/index',
        },
        {
          path: '/courseManage/xiaoke',
          component: '@/pages/CourseManage/XiaoKe/index',
        },
        {
          path: '/courseManage/studentCourseBinding',
          component: '@/pages/CourseManage/StudentCourseBinding/index',
        },
        {
          path: '/courseManage/lessonChange',
          component: '@/pages/CourseManage/LessonChange/index',
        },
        {
          path: '/courseManage/CourseGroupStatus',
          component: '@/pages/CourseManage/CourseGroupStatus/index',
        },
        {
          path: '/courseManage/userTeacher',
          component: '@/pages/CourseManage/UserTeacher/index',
        },
        {
          path: '/courseManage/userTeacherXiaoke',
          component: '@/pages/CourseManage/UserTeacherXiaoKe/index',
        },
        {
          path: '/account/stuSelfAccount',
          component: '@/pages/AccountManage/StudentSelf/index',
        },
        {
          path: '/accountManage/labels',
          component: '@/pages/AccountManage/LabelsManage/index',
        },
        {
          path: '/courseManage/stuSelfCourses',
          component: '@/pages/CourseManage/StudentSelfCourses/index',
        },
        {
          path: '/informationManage/consultRegistration',
          component: '@/pages/InformationManage/ConsultRegistration/index',
        },
        {
          path: '/informationManage/summary',
          component: '@/pages/InformationManage/Summary/index',
        },
        {
          path: '/informationManage/budgetRegistration',
          component: '@/pages/InformationManage/BudgetRegistration/index',
        },
        {
          path: '/informationManage/PayImage',
          component: '@/pages/InformationManage/PayImage/index',
        },
        {
          path: '/informationManage/stuPay',
          component: '@/pages/InformationManage/StuSelfPay/index',
        },
        {
          path: '/accountManage/timeScale',
          component: '@/pages/AccountManage/timeScale/index',
        },
      ],
    },
  ],
  tailwindcss: {},
  theme:
    antdVersion === '4'
      ? {
          '@primary-color': primaryColor,
        }
      : {},
});
