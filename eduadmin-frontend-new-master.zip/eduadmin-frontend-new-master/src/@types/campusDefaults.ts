export const defaultCampusInfo: Campus.CampusInfo = {
  students: [],
  teachers: [],
};
