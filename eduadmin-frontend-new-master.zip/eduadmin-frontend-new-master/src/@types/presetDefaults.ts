export const defaultTimescalePreset: Preset.TimescalePresetInfo = {
  id: 0,
  name: '',
  description: '',
  value: [],
};
