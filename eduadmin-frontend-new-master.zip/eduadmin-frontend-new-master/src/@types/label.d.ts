declare namespace Label {
  interface LabelInfo {
    id: number;
    name: string;
    category: string;
    description: string;
  }
}
