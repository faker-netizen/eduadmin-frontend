export const defaultLabelInfo: Label.LabelInfo = {
  id: 0,
  name: '',
  category: '',
  description: '',
};
