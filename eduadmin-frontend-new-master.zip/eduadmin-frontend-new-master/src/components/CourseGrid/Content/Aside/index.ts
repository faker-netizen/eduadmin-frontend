import Aside from './Aside';

export default Aside;
export type { AsideProps } from './Aside';
