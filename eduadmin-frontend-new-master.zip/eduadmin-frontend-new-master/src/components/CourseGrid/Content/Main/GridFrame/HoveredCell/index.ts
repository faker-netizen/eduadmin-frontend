import HoveredCell from './HoveredCell';

export default HoveredCell;
export type { HoveredCellProps } from './HoveredCell';
