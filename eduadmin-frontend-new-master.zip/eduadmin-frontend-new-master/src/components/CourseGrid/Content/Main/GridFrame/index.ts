import GridFrame from './GridFrame';

export default GridFrame;
export type { GridFrameProps as CourseGridMainProps } from './GridFrame';
