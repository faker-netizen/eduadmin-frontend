import CourseCell from './CourseCell';

export default CourseCell;
export type { CourseCellProps } from './CourseCell';
