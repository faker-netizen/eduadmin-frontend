import Main from './Main';

export default Main;
export type { MainProps } from './Main';
