import Content from './Content';

export default Content;
export type { ContentProps } from './Content';
