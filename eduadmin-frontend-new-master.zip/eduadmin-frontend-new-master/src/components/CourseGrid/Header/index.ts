import Header from './Header';

export default Header;
export type { HeaderProps } from './Header';
