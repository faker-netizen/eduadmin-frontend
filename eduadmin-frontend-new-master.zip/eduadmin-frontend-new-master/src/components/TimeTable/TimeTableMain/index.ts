import TimeTableMain from './TimeTableMain';

export default TimeTableMain;
export type { TimeTableMainProps } from './TimeTableMain';
