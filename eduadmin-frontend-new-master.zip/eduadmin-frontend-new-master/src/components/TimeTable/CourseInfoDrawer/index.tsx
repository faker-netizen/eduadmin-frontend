import CourseInfoDrawer from './CourseInfoDrawer';

export default CourseInfoDrawer;
export type { CourseInfoDrawerProps } from './CourseInfoDrawer';
