import TimeTable from './TimeTable';

export default TimeTable;
export type { TimeTableProps } from './TimeTable';
