import TimeTableCell from './TimeTableCell';

export default TimeTableCell;
export type { TimeTableCellProps } from './TimeTableCell';
