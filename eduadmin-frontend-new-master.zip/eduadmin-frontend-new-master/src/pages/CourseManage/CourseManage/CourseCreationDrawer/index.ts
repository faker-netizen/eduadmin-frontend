import CourseCreationDrawer from './CourseCreationDrawer';

export default CourseCreationDrawer;
export type { CourseCreationDrawerProps } from './CourseCreationDrawer';
