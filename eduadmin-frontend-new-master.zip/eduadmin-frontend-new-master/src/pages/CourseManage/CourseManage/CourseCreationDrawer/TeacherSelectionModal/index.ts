import TeacherSelectionModal from './TeacherSelectionModal';

export default TeacherSelectionModal;
export type { TeacherSelectionModalProps } from './TeacherSelectionModal';
