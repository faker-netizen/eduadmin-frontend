import ClassCreationModal from './ClassCreationModal';

export default ClassCreationModal;
export type { ClassCreationModalProps } from './ClassCreationModal';
