import styles from './index.less';

const UserPage: React.FC = () => {
  return (
    <div>
      <h1 className={styles['title']}>user</h1>
    </div>
  );
};

export default UserPage;
