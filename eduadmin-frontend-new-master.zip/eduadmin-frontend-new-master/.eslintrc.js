module.exports = {
  extends: [require.resolve('@umijs/max/eslint')],
  rules: {
    'no-console': 0,
    '@typescript-eslint/no-unused-vars': 0,
    '@typescript-eslint/no-use-before-define': 0
  },


};
