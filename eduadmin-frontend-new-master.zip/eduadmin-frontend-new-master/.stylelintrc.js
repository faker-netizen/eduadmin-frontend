module.exports = {
  extends: require.resolve('@umijs/max/stylelint'),
  // 忽略Tailwind CSS的样式检查
  ignoreFiles: ['**/*.css'],
};
